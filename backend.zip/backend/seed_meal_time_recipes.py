"""
Script to add meal time categories to existing recipes.
This adds a second category field (meal_time) to categorize by time of day.
Since SQLite doesn't support multiple categories easily, we'll add new recipes
specifically for meal times that reference existing recipes.
"""
from app.db.session import SessionLocal
from app.models.recipe import Recipe
import uuid

def generate_uuid():
    return str(uuid.uuid4())

def seed_meal_time_recipes():
    db = SessionLocal()
    
    # Define recipes for each meal time based on what makes sense
    # Using existing recipe data as templates but with meal time categories
    
    meal_time_recipes = [
        # Morning (Breakfast items)
        {
            "title": "Masala Tea",
            "description": "Hot and spicy Indian masala chai with aromatic spices - perfect to start your morning",
            "cooking_time_minutes": 10,
            "price": 49.0,
            "difficulty": "Easy",
            "rating": 4.8,
            "is_vegetarian": True,
            "category": "Morning",
            "cuisine": "Indian",
            "image_url": "android.resource://com.combocart/drawable/masala_tea"
        },
        {
            "title": "Upma",
            "description": "South Indian savory semolina dish with vegetables - a wholesome breakfast",
            "cooking_time_minutes": 15,
            "price": 79.0,
            "difficulty": "Easy",
            "rating": 4.4,
            "is_vegetarian": True,
            "category": "Morning",
            "cuisine": "South Indian",
            "image_url": "android.resource://com.combocart/drawable/upma"
        },
        {
            "title": "Vada Pav",
            "description": "Mumbai's famous morning street food - spiced potato fritter in a bun",
            "cooking_time_minutes": 20,
            "price": 59.0,
            "difficulty": "Easy",
            "rating": 4.6,
            "is_vegetarian": True,
            "category": "Morning",
            "cuisine": "Indian",
            "image_url": "android.resource://com.combocart/drawable/vada_pav"
        },
        {
            "title": "Samosa",
            "description": "Crispy fried pastry with spiced potatoes - classic breakfast snack",
            "cooking_time_minutes": 25,
            "price": 79.0,
            "difficulty": "Medium",
            "rating": 4.7,
            "is_vegetarian": True,
            "category": "Morning",
            "cuisine": "Indian",
            "image_url": "android.resource://com.combocart/drawable/samosa"
        },
        
        # Noon (Lunch items)
        {
            "title": "Sambar Rice",
            "description": "Traditional South Indian lentil stew with vegetables - perfect lunch combo",
            "cooking_time_minutes": 30,
            "price": 129.0,
            "difficulty": "Medium",
            "rating": 4.7,
            "is_vegetarian": True,
            "category": "Noon",
            "cuisine": "South Indian",
            "image_url": "android.resource://com.combocart/drawable/sambar_rice"
        },
        {
            "title": "Dal Chawal",
            "description": "Hearty yellow dal with steamed basmati rice - a satisfying lunch",
            "cooking_time_minutes": 25,
            "price": 109.0,
            "difficulty": "Easy",
            "rating": 4.6,
            "is_vegetarian": True,
            "category": "Noon",
            "cuisine": "North Indian",
            "image_url": "android.resource://com.combocart/drawable/dal_chawal"
        },
        {
            "title": "Rasam Rice",
            "description": "Warm and tangy rasam served with steamed rice - light and refreshing lunch",
            "cooking_time_minutes": 20,
            "price": 119.0,
            "difficulty": "Easy",
            "rating": 4.6,
            "is_vegetarian": True,
            "category": "Noon",
            "cuisine": "South Indian",
            "image_url": "android.resource://com.combocart/drawable/rasam_rice"
        },
        {
            "title": "Biryani Combo",
            "description": "Aromatic basmati rice cooked with spices and tender meat - lunch special",
            "cooking_time_minutes": 45,
            "price": 349.0,
            "difficulty": "Medium",
            "rating": 4.9,
            "is_vegetarian": False,
            "category": "Noon",
            "cuisine": "Indian",
            "image_url": "android.resource://com.combocart/drawable/biriyani_combo_img5"
        },
        
        # Evening (Snacks)
        {
            "title": "Bajji",
            "description": "Deep fried vegetable fritters - perfect evening snack with tea",
            "cooking_time_minutes": 20,
            "price": 69.0,
            "difficulty": "Easy",
            "rating": 4.5,
            "is_vegetarian": True,
            "category": "Evening",
            "cuisine": "Indian",
            "image_url": "android.resource://com.combocart/drawable/bajji"
        },
        {
            "title": "French Fries",
            "description": "Crispy golden potato fries - perfect evening munchies",
            "cooking_time_minutes": 15,
            "price": 99.0,
            "difficulty": "Easy",
            "rating": 4.5,
            "is_vegetarian": True,
            "category": "Evening",
            "cuisine": "American",
            "image_url": "android.resource://com.combocart/drawable/french_fries"
        },
        {
            "title": "Maggi",
            "description": "India's favorite instant noodles - quick evening fix",
            "cooking_time_minutes": 10,
            "price": 59.0,
            "difficulty": "Easy",
            "rating": 4.6,
            "is_vegetarian": True,
            "category": "Evening",
            "cuisine": "Indian",
            "image_url": "android.resource://com.combocart/drawable/maggi"
        },
        {
            "title": "Momos",
            "description": "Steamed dumplings with spicy chutney - popular evening snack",
            "cooking_time_minutes": 30,
            "price": 149.0,
            "difficulty": "Medium",
            "rating": 4.7,
            "is_vegetarian": True,
            "category": "Evening",
            "cuisine": "Tibetan",
            "image_url": "android.resource://com.combocart/drawable/momos"
        },
        
        # Night (Dinner items)
        {
            "title": "Butter Chicken Combo",
            "description": "Creamy tomato-based curry with tender chicken - dinner favorite",
            "cooking_time_minutes": 40,
            "price": 299.0,
            "difficulty": "Medium",
            "rating": 4.8,
            "is_vegetarian": False,
            "category": "Night",
            "cuisine": "North Indian",
            "image_url": "android.resource://com.combocart/drawable/butter_chicken_combo_img2"
        },
        {
            "title": "Kadai Paneer",
            "description": "Rich and spicy cottage cheese curry - perfect dinner dish",
            "cooking_time_minutes": 35,
            "price": 279.0,
            "difficulty": "Medium",
            "rating": 4.8,
            "is_vegetarian": True,
            "category": "Night",
            "cuisine": "North Indian",
            "image_url": "android.resource://com.combocart/drawable/kadai_paneer"
        },
        {
            "title": "Parotta",
            "description": "Flaky layered flatbread served with spicy curry - South Indian dinner",
            "cooking_time_minutes": 20,
            "price": 89.0,
            "difficulty": "Medium",
            "rating": 4.6,
            "is_vegetarian": True,
            "category": "Night",
            "cuisine": "South Indian",
            "image_url": "android.resource://com.combocart/drawable/parotta"
        },
        {
            "title": "Fried Rice",
            "description": "Indo-Chinese style fried rice - quick and satisfying dinner",
            "cooking_time_minutes": 20,
            "price": 149.0,
            "difficulty": "Easy",
            "rating": 4.5,
            "is_vegetarian": True,
            "category": "Night",
            "cuisine": "Indo-Chinese",
            "image_url": "android.resource://com.combocart/drawable/fried_rice"
        },
    ]
    
    added_count = 0
    for recipe_data in meal_time_recipes:
        # Check if this meal-time version already exists
        existing = db.query(Recipe).filter(
            Recipe.title == recipe_data["title"],
            Recipe.category == recipe_data["category"]
        ).first()
        
        if existing:
            print(f"Skipping existing: {recipe_data['title']} ({recipe_data['category']})")
            continue
        
        recipe = Recipe(
            id=generate_uuid(),
            title=recipe_data["title"],
            description=recipe_data["description"],
            cooking_time_minutes=recipe_data["cooking_time_minutes"],
            price=recipe_data["price"],
            difficulty=recipe_data["difficulty"],
            rating=recipe_data["rating"],
            is_vegetarian=recipe_data["is_vegetarian"],
            category=recipe_data["category"],
            cuisine=recipe_data.get("cuisine", "Indian"),
            image_url=recipe_data.get("image_url"),
            servings=2,
            num_reviews=100
        )
        db.add(recipe)
        added_count += 1
        print(f"Added: {recipe_data['title']} -> {recipe_data['category']}")
    
    db.commit()
    db.close()
    print(f"\n✓ Added {added_count} meal time recipes!")

if __name__ == "__main__":
    print("Seeding meal time recipes...")
    seed_meal_time_recipes()
