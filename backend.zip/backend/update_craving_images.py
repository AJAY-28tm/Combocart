"""
Script to update craving recipe image_url fields in the database.
Maps each recipe to its corresponding drawable image.
"""
from app.db.session import SessionLocal
from app import models

def update_craving_recipe_images():
    db = SessionLocal()
    
    # Mapping: Recipe Title -> Drawable name (without extension)
    image_mapping = {
        # Rainy Day
        "Masala Tea": "masala_tea",
        "Samosa": "samosa",
        "Bajji": "bajji",
        "Vada Pav": "vada_pav",
        
        # Comfort Food
        "Curd Rice": "curd_rice",
        "Rasam Rice": "rasam_rice",
        "Sambar Rice": "sambar_rice",
        "Dal Chawal": "dal_chawal",
        
        # Late Night
        "Fried Chicken": "fried_chicken",
        "Shawarma": "shawarma",
        "French Fries": "french_fries",
        "Parotta": "parotta",
        "Fried Rice": "fried_rice",
        
        # Date Night
        "Hot Chocolate": "hot_chocolate",
        "Chocolate Lava Cake": "chocolate_lava_cake",
        "Momos": "momos",
        "Loaded Fries": "loaded_fries",
        "Kadai Paneer": "kadai_paneer",
        "Pizza": "pizza",
        
        # Quick Meals
        "Maggi": "maggi",
        "Instant Pasta": "instant_pasta",
        "Upma": "upma",
        "Egg Rice": "egg_rice",
    }
    
    updated_count = 0
    for title, drawable_name in image_mapping.items():
        recipe = db.query(models.Recipe).filter(models.Recipe.title == title).first()
        if recipe:
            image_url = f"android.resource://com.combocart/drawable/{drawable_name}"
            recipe.image_url = image_url
            updated_count += 1
            print(f"Updated: {title} -> {drawable_name}")
        else:
            print(f"Recipe not found: {title}")
    
    db.commit()
    db.close()
    print(f"\n✓ Updated {updated_count} craving recipe images!")

if __name__ == "__main__":
    print("Updating craving recipe images...")
    update_craving_recipe_images()
