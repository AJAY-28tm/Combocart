from sqlalchemy.orm import Session
from app.db.session import SessionLocal
from app import crud, schemas, models
import uuid

def seed_recipes():
    db = SessionLocal()
    
    recipes = [
        {
            "title": "Butter Chicken Combo",
            "description": "Rich and creamy butter chicken served with butter naan and jeera rice.",
            "price": 299.0,
            "cooking_time_minutes": 35,
            "difficulty": "Medium",
            "rating": 4.5,
            "is_vegetarian": False,
            "category": "Combos"
        },
        {
            "title": "Paneer Tikka Masala",
            "description": "Grilled paneer cubes in a spicy and aromatic tomato-based gravy.",
            "price": 249.0,
            "cooking_time_minutes": 30,
            "difficulty": "Easy",
            "rating": 4.2,
            "is_vegetarian": True,
            "category": "Main Course"
        },
        {
            "title": "Pasta Carbonara Kit",
            "description": "Authentic Italian carbonara kit with guanciale, pecorino romano, and fresh pasta.",
            "price": 349.0,
            "cooking_time_minutes": 25,
            "difficulty": "Medium",
            "rating": 4.8,
            "is_vegetarian": False,
            "category": "Kits"
        },
        {
            "title": "Biryani Combo",
            "description": "Flavorful Hyderabadi biryani with raita, salan, and a gulab jamun.",
            "price": 399.0,
            "cooking_time_minutes": 45,
            "difficulty": "Hard",
            "rating": 4.7,
            "is_vegetarian": False,
            "category": "Combos"
        },
        {
            "title": "Pad Thai Kit",
            "description": "Everything you need to make classic Pad Thai at home in 20 minutes.",
            "price": 279.0,
            "cooking_time_minutes": 20,
            "difficulty": "Easy",
            "rating": 4.0,
            "is_vegetarian": True,
            "category": "Kits"
        },
        {
            "title": "Margherita Pizza Kit",
            "description": "Fresh dough, San Marzano tomato sauce, and mozzarella di bufala.",
            "price": 229.0,
            "cooking_time_minutes": 30,
            "difficulty": "Easy",
            "rating": 4.6,
            "is_vegetarian": True,
            "category": "Kits"
        }
    ]

    for r_data in recipes:
        # Check if exists
        existing = db.query(models.Recipe).filter(models.Recipe.title == r_data["title"]).first()
        if not existing:
            recipe_in = schemas.RecipeCreate(**r_data)
            crud.recipe.create(db, obj_in=recipe_in)
            print(f"Created: {r_data['title']}")
        else:
            print(f"Skipped: {r_data['title']} (exists)")

    db.close()

if __name__ == "__main__":
    print("Seeding more recipes...")
    seed_recipes()
    print("Done!")
