import urllib.request
import json
import sqlite3
import time

BASE_URL = "http://127.0.0.1:8000/api/v1"
DB_PATH = "./sql_app.db"

def make_superuser(phone):
    print(f"   -> Promoting user {phone} to superuser...")
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET is_superuser = 1 WHERE phone = ?", (phone,))
    conn.commit()
    conn.close()

def test_recipes():
    phone = "1234567890"
    
    # 0. Promote user to superuser (Hack for testing)
    try:
        make_superuser(phone)
    except Exception as e:
        print(f"Warning: Could not update DB directly: {e}")

    # 1. Login
    print("1. Logging in...")
    login_url = f"{BASE_URL}/login/otp/verify"
    login_data = {"phone_number": phone, "otp": "1234"}
    headers = {"Content-Type": "application/json"}
    
    try:
        req = urllib.request.Request(login_url, json.dumps(login_data).encode('utf-8'), headers)
        with urllib.request.urlopen(req) as res:
            response = json.loads(res.read().decode('utf-8'))
            token = response.get("access_token")
            print(f"   Login Success!")
    except Exception as e:
        print(f"   Login Failed: {e}")
        return

    auth_headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    # 2. Create Recipe
    print("\n2. Creating Recipe...")
    recipe_data = {
        "title": "Spicy Chicken Curry",
        "description": "A delicious and spicy home-style chicken curry.",
        "cooking_time_minutes": 45,
        "price": 350.0,
        "difficulty": "Medium",
        "category": "Dinner",
        "cuisine": "Indian",
        "is_vegetarian": False,
        "calories": 500,
        "ingredients_list": "Chicken, Onions, Tomatoes, Spices"
    }
    
    try:
        req = urllib.request.Request(f"{BASE_URL}/recipes/", json.dumps(recipe_data).encode('utf-8'), headers=auth_headers)
        with urllib.request.urlopen(req) as res:
            created_recipe = json.loads(res.read().decode('utf-8'))
            print(f"   Created Recipe: {created_recipe['title']} (ID: {created_recipe['id']})")
    except Exception as e:
        print(f"   Create Recipe Failed: {e}")
        # If 400, maybe not superuser?
        try:
             print(e.read().decode())
        except:
             pass

    # 3. List Recipes
    print("\n3. Listing Recipes...")
    try:
        req = urllib.request.Request(f"{BASE_URL}/recipes/", headers=auth_headers)
        with urllib.request.urlopen(req) as res:
            recipes = json.loads(res.read().decode('utf-8'))
            print(f"   Fetched {len(recipes)} recipes.")
            for r in recipes:
                print(f"   - {r['title']} ({r['price']} {r['currency']})")
    except Exception as e:
        print(f"   List Recipes Failed: {e}")

if __name__ == "__main__":
    time.sleep(2) # Wait for server start
    test_recipes()
