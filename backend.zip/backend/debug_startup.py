import sys
import traceback

try:
    import main
    print("App imported successfully")
except Exception:
    traceback.print_exc()
