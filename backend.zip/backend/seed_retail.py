import sys
import os
from sqlalchemy.orm import Session

# Add the parent directory to sys.path to import app
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.db.session import SessionLocal, engine
from app.models.retail import RetailItem
from app import models

def seed_retail():
    db = SessionLocal()
    try:
        # Check if items exist
        existing = db.query(RetailItem).first()
        if existing:
            print("Retail items already exist. Adding more stock...")
            db.query(RetailItem).update({RetailItem.stock_quantity: 100, RetailItem.is_available: True})
            db.commit()
            return

        # Add some grocery items
        groceries = [
            RetailItem(
                name="Fresh Tomatoes",
                description="Organic vine-ripened tomatoes",
                price=40.0,
                category="Vegetables",
                stock_quantity=50,
                is_available=True
            ),
            RetailItem(
                name="Amul Milk (1L)",
                description="Full cream milk",
                price=66.0,
                category="Dairy",
                stock_quantity=100,
                is_available=True
            ),
            RetailItem(
                name="Aashirvaad Atta (5kg)",
                description="Whole wheat flour",
                price=245.0,
                category="Grains",
                stock_quantity=20,
                is_available=True
            ),
            RetailItem(
                name="Eggs (12 pcs)",
                description="Farm fresh brown eggs",
                price=90.0,
                category="Dairy & Eggs",
                stock_quantity=30,
                is_available=True
            )
        ]
        db.add_all(groceries)
        db.commit()
        print("Successfully seeded retail grocery items with stock!")
    except Exception as e:
        print(f"Error seeding: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    seed_retail()
