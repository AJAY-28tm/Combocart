import urllib.request
import json

url = "http://127.0.0.1:8000/api/v1/login/otp/verify"
data = {"phone_number": "1234567890", "otp": "1234"}
headers = {"Content-Type": "application/json"}

try:
    req = urllib.request.Request(url, json.dumps(data).encode('utf-8'), headers)
    with urllib.request.urlopen(req) as res:
        print(res.read().decode('utf-8'))
except Exception as e:
    print(f"Error: {e}")
    # Print error body if available
    try:
        print(e.read().decode())
    except:
        pass
