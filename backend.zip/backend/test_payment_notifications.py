import urllib.request
import json
import time

BASE_URL = "http://127.0.0.1:8000/api/v1"

def test_payment_notifications():
    print("Testing Payment & Notifications Flow...")
    
    # 1. Login
    print("1. Logging in...")
    login_url = f"{BASE_URL}/login/otp/verify"
    login_data = {"phone_number": "1234567890", "otp": "1234"}
    headers = {"Content-Type": "application/json"}
    
    try:
        req = urllib.request.Request(login_url, json.dumps(login_data).encode('utf-8'), headers)
        with urllib.request.urlopen(req) as res:
            response = json.loads(res.read().decode('utf-8'))
            token = response.get("access_token")
    except Exception as e:
        print(f"   Login Failed: {e}")
        return

    auth_headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    
    # 2. Setup: Add to Cart and Place Order (Need an order to pay for)
    print("\n2. Placing a new order to pay for...")
    # Fetch recipe
    try:
        req = urllib.request.Request(f"{BASE_URL}/recipes/", headers=auth_headers)
        with urllib.request.urlopen(req) as res:
            recipes = json.loads(res.read().decode('utf-8'))
            if not recipes: return
            recipe_id = recipes[0]['id']
    except: return

    # Add to cart
    cart_data = {"recipe_id": recipe_id, "quantity": 1}
    urllib.request.urlopen(urllib.request.Request(f"{BASE_URL}/orders/cart", json.dumps(cart_data).encode('utf-8'), headers=auth_headers))
    
    # Place Order
    order_data = {"address_line": "Payment Test Addr", "latitude": 0, "longitude": 0}
    try:
        req = urllib.request.Request(f"{BASE_URL}/orders/", json.dumps(order_data).encode('utf-8'), headers=auth_headers)
        with urllib.request.urlopen(req) as res:
            order = json.loads(res.read().decode('utf-8'))
            order_id = order['id']
            print(f"   Order Placed: {order_id} (Status: {order['status']})")
    except Exception as e:
        print(f"   Place Order Failed: {e}")
        return

    # 3. Process Payment
    print("\n3. Processing Payment...")
    payment_data = {"order_id": order_id, "amount": 100.0, "provider": "TestPay"}
    try:
        req = urllib.request.Request(f"{BASE_URL}/payments/process", json.dumps(payment_data).encode('utf-8'), headers=auth_headers)
        with urllib.request.urlopen(req) as res:
            payment = json.loads(res.read().decode('utf-8'))
            print(f"   Payment Successful! TXN ID: {payment['transaction_id']}")
    except Exception as e:
        print(f"   Payment Failed: {e}")
        try: print(e.read().decode()) 
        except: pass

    # 4. Check Notifications
    print("\n4. Checking Notifications...")
    try:
        req = urllib.request.Request(f"{BASE_URL}/notifications/", headers=auth_headers)
        with urllib.request.urlopen(req) as res:
            notifs = json.loads(res.read().decode('utf-8'))
            print(f"   Found {len(notifs)} notifications.")
            for n in notifs:
                print(f"   - {n['title']}: {n['message']}")
    except Exception as e:
        print(f"   Get Notifications Failed: {e}")

if __name__ == "__main__":
    time.sleep(2)
    test_payment_notifications()
