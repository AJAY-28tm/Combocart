"""
Script to seed craving-specific recipes into the database.
"""
from app.db.session import SessionLocal
from app.models.recipe import Recipe
import uuid

def generate_uuid():
    return str(uuid.uuid4())

def seed_cravings_recipes():
    db = SessionLocal()
    
    # Define all the recipes by category
    recipes_data = [
        # Rainy Day
        {
            "title": "Masala Tea",
            "description": "Hot and spicy Indian masala chai with aromatic spices",
            "cooking_time_minutes": 10,
            "price": 49.0,
            "difficulty": "Easy",
            "rating": 4.8,
            "is_vegetarian": True,
            "category": "Rainy Day",
            "cuisine": "Indian"
        },
        {
            "title": "Samosa",
            "description": "Crispy fried pastry filled with spiced potatoes and peas",
            "cooking_time_minutes": 25,
            "price": 79.0,
            "difficulty": "Medium",
            "rating": 4.7,
            "is_vegetarian": True,
            "category": "Rainy Day",
            "cuisine": "Indian"
        },
        {
            "title": "Bajji",
            "description": "Deep fried vegetable fritters coated with spiced gram flour batter",
            "cooking_time_minutes": 20,
            "price": 69.0,
            "difficulty": "Easy",
            "rating": 4.5,
            "is_vegetarian": True,
            "category": "Rainy Day",
            "cuisine": "Indian"
        },
        {
            "title": "Vada Pav",
            "description": "Mumbai's famous street food - spiced potato fritter in a bun with chutneys",
            "cooking_time_minutes": 20,
            "price": 59.0,
            "difficulty": "Easy",
            "rating": 4.6,
            "is_vegetarian": True,
            "category": "Rainy Day",
            "cuisine": "Indian"
        },
        
        # Comfort Food
        {
            "title": "Curd Rice",
            "description": "Soothing South Indian rice mixed with creamy yogurt and tempered with spices",
            "cooking_time_minutes": 15,
            "price": 99.0,
            "difficulty": "Easy",
            "rating": 4.5,
            "is_vegetarian": True,
            "category": "Comfort Food",
            "cuisine": "South Indian"
        },
        {
            "title": "Rasam Rice",
            "description": "Warm and tangy rasam served with steamed rice, a South Indian comfort classic",
            "cooking_time_minutes": 20,
            "price": 119.0,
            "difficulty": "Easy",
            "rating": 4.6,
            "is_vegetarian": True,
            "category": "Comfort Food",
            "cuisine": "South Indian"
        },
        {
            "title": "Sambar Rice",
            "description": "Traditional South Indian lentil stew with vegetables served over rice",
            "cooking_time_minutes": 30,
            "price": 129.0,
            "difficulty": "Medium",
            "rating": 4.7,
            "is_vegetarian": True,
            "category": "Comfort Food",
            "cuisine": "South Indian"
        },
        {
            "title": "Dal Chawal",
            "description": "Hearty yellow dal with steamed basmati rice, a North Indian staple",
            "cooking_time_minutes": 25,
            "price": 109.0,
            "difficulty": "Easy",
            "rating": 4.6,
            "is_vegetarian": True,
            "category": "Comfort Food",
            "cuisine": "North Indian"
        },
        
        # Late Night
        {
            "title": "Fried Chicken",
            "description": "Crispy golden fried chicken pieces marinated in aromatic spices",
            "cooking_time_minutes": 30,
            "price": 249.0,
            "difficulty": "Medium",
            "rating": 4.8,
            "is_vegetarian": False,
            "category": "Late Night",
            "cuisine": "American"
        },
        {
            "title": "Shawarma",
            "description": "Middle Eastern wrap with spiced grilled meat, garlic sauce and pickles",
            "cooking_time_minutes": 25,
            "price": 179.0,
            "difficulty": "Medium",
            "rating": 4.7,
            "is_vegetarian": False,
            "category": "Late Night",
            "cuisine": "Middle Eastern"
        },
        {
            "title": "French Fries",
            "description": "Crispy golden potato fries seasoned with salt and spices",
            "cooking_time_minutes": 15,
            "price": 99.0,
            "difficulty": "Easy",
            "rating": 4.5,
            "is_vegetarian": True,
            "category": "Late Night",
            "cuisine": "American"
        },
        {
            "title": "Parotta",
            "description": "Flaky layered flatbread served with spicy curry",
            "cooking_time_minutes": 20,
            "price": 89.0,
            "difficulty": "Medium",
            "rating": 4.6,
            "is_vegetarian": True,
            "category": "Late Night",
            "cuisine": "South Indian"
        },
        {
            "title": "Fried Rice",
            "description": "Indo-Chinese style fried rice with vegetables and savory sauces",
            "cooking_time_minutes": 20,
            "price": 149.0,
            "difficulty": "Easy",
            "rating": 4.5,
            "is_vegetarian": True,
            "category": "Late Night",
            "cuisine": "Indo-Chinese"
        },
        
        # Date Night
        {
            "title": "Hot Chocolate",
            "description": "Rich and creamy hot chocolate topped with marshmallows",
            "cooking_time_minutes": 10,
            "price": 129.0,
            "difficulty": "Easy",
            "rating": 4.8,
            "is_vegetarian": True,
            "category": "Date Night",
            "cuisine": "Continental"
        },
        {
            "title": "Chocolate Lava Cake",
            "description": "Decadent chocolate cake with a molten chocolate center",
            "cooking_time_minutes": 25,
            "price": 199.0,
            "difficulty": "Medium",
            "rating": 4.9,
            "is_vegetarian": True,
            "category": "Date Night",
            "cuisine": "Continental"
        },
        {
            "title": "Momos",
            "description": "Steamed dumplings filled with vegetables or meat, served with spicy chutney",
            "cooking_time_minutes": 30,
            "price": 149.0,
            "difficulty": "Medium",
            "rating": 4.7,
            "is_vegetarian": True,
            "category": "Date Night",
            "cuisine": "Tibetan"
        },
        {
            "title": "Loaded Fries",
            "description": "Crispy fries topped with cheese, jalapeños, and special sauce",
            "cooking_time_minutes": 20,
            "price": 179.0,
            "difficulty": "Easy",
            "rating": 4.6,
            "is_vegetarian": True,
            "category": "Date Night",
            "cuisine": "American"
        },
        {
            "title": "Kadai Paneer",
            "description": "Rich and spicy cottage cheese curry cooked in a kadai with bell peppers",
            "cooking_time_minutes": 35,
            "price": 279.0,
            "difficulty": "Medium",
            "rating": 4.8,
            "is_vegetarian": True,
            "category": "Date Night",
            "cuisine": "North Indian"
        },
        {
            "title": "Pizza",
            "description": "Classic pizza with mozzarella cheese, tomato sauce and your choice of toppings",
            "cooking_time_minutes": 30,
            "price": 299.0,
            "difficulty": "Medium",
            "rating": 4.7,
            "is_vegetarian": True,
            "category": "Date Night",
            "cuisine": "Italian"
        },
        
        # Quick Meals
        {
            "title": "Maggi",
            "description": "India's favorite instant noodles made with special masala",
            "cooking_time_minutes": 10,
            "price": 59.0,
            "difficulty": "Easy",
            "rating": 4.6,
            "is_vegetarian": True,
            "category": "Quick Meals",
            "cuisine": "Indian"
        },
        {
            "title": "Instant Pasta",
            "description": "Quick and delicious pasta in creamy white sauce or tangy red sauce",
            "cooking_time_minutes": 15,
            "price": 99.0,
            "difficulty": "Easy",
            "rating": 4.5,
            "is_vegetarian": True,
            "category": "Quick Meals",
            "cuisine": "Italian"
        },
        {
            "title": "Upma",
            "description": "South Indian savory semolina dish with vegetables and spices",
            "cooking_time_minutes": 15,
            "price": 79.0,
            "difficulty": "Easy",
            "rating": 4.4,
            "is_vegetarian": True,
            "category": "Quick Meals",
            "cuisine": "South Indian"
        },
        {
            "title": "Egg Rice",
            "description": "Quick and flavorful fried rice with scrambled eggs and spices",
            "cooking_time_minutes": 15,
            "price": 119.0,
            "difficulty": "Easy",
            "rating": 4.5,
            "is_vegetarian": False,
            "category": "Quick Meals",
            "cuisine": "Indian"
        },
    ]
    
    added_count = 0
    for recipe_data in recipes_data:
        # Check if recipe already exists
        existing = db.query(Recipe).filter(Recipe.title == recipe_data["title"]).first()
        if existing:
            print(f"Skipping existing recipe: {recipe_data['title']}")
            continue
        
        recipe = Recipe(
            id=generate_uuid(),
            title=recipe_data["title"],
            description=recipe_data["description"],
            cooking_time_minutes=recipe_data["cooking_time_minutes"],
            price=recipe_data["price"],
            difficulty=recipe_data["difficulty"],
            rating=recipe_data["rating"],
            is_vegetarian=recipe_data["is_vegetarian"],
            category=recipe_data["category"],
            cuisine=recipe_data.get("cuisine", "Indian"),
            servings=2,
            num_reviews=100
        )
        db.add(recipe)
        added_count += 1
        print(f"Added: {recipe_data['title']} -> {recipe_data['category']}")
    
    db.commit()
    db.close()
    print(f"\n✓ Added {added_count} new craving recipes!")

if __name__ == "__main__":
    print("Seeding craving recipes...")
    seed_cravings_recipes()
