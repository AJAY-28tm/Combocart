import urllib.request
import json
import time

BASE_URL = "http://127.0.0.1:8000/api/v1"

def test_orders():
    print("Testing Orders & Cart Flow...")
    
    # 1. Login
    print("1. Logging in...")
    login_url = f"{BASE_URL}/login/otp/verify"
    login_data = {"phone_number": "1234567890", "otp": "1234"}
    headers = {"Content-Type": "application/json"}
    
    try:
        req = urllib.request.Request(login_url, json.dumps(login_data).encode('utf-8'), headers)
        with urllib.request.urlopen(req) as res:
            response = json.loads(res.read().decode('utf-8'))
            token = response.get("access_token")
            # print(f"   Login Success! Token: {token[:10]}...")
    except Exception as e:
        print(f"   Login Failed: {e}")
        return

    auth_headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    # 2. Get a Recipe ID to add to cart (Assuming one exists from prev test)
    print("\n2. Fetching Recipes to get ID...")
    recipe_id = None
    try:
        req = urllib.request.Request(f"{BASE_URL}/recipes/", headers=auth_headers)
        with urllib.request.urlopen(req) as res:
            recipes = json.loads(res.read().decode('utf-8'))
            if recipes:
                recipe_id = recipes[0]['id']
                print(f"   Found Recipe: {recipes[0]['title']} (ID: {recipe_id})")
            else:
                print("   No recipes found. Create one first.")
                return
    except Exception as e:
        print(f"   Fetch Recipes Failed: {e}")
        return

    # 3. Add to Cart
    print("\n3. Adding to Cart...")
    cart_data = {"recipe_id": recipe_id, "quantity": 2}
    try:
        req = urllib.request.Request(f"{BASE_URL}/orders/cart", json.dumps(cart_data).encode('utf-8'), headers=auth_headers)
        with urllib.request.urlopen(req) as res:
            cart = json.loads(res.read().decode('utf-8'))
            # print(f"   Cart: {cart}")
            if len(cart['items']) > 0 and cart['total_price'] > 0:
                 print(f"   Cart Updated! Total Items: {len(cart['items'])}, Total Price: {cart['total_price']}")
            else:
                 print("   Cart update failed check.")
    except Exception as e:
        print(f"   Add to Cart Failed: {e}")

    # 4. Place Order
    print("\n4. Placing Order...")
    order_data = {"address_line": "123 Test St", "latitude": 12.0, "longitude": 77.0}
    try:
        req = urllib.request.Request(f"{BASE_URL}/orders/", json.dumps(order_data).encode('utf-8'), headers=auth_headers)
        with urllib.request.urlopen(req) as res:
            order = json.loads(res.read().decode('utf-8'))
            print(f"   Order Placed! ID: {order['id']}, Status: {order['status']}, Total: {order['total_amount']}")
    except Exception as e:
        print(f"   Place Order Failed: {e}")
        try:
             print(e.read().decode())
        except:
             pass

    # 5. List Orders
    print("\n5. Listing Orders...")
    try:
        req = urllib.request.Request(f"{BASE_URL}/orders/", headers=auth_headers)
        with urllib.request.urlopen(req) as res:
            orders = json.loads(res.read().decode('utf-8'))
            print(f"   Found {len(orders)} orders.")
            for o in orders:
                print(f"   - Order {o['id']}: {o['status']} ({len(o['items'])} items)")
    except Exception as e:
        print(f"   List Orders Failed: {e}")

if __name__ == "__main__":
    time.sleep(2)
    test_orders()
