from typing import List, Optional
from sqlalchemy.orm import Session
from app.crud.base import CRUDBase
from app.models.recipe import Recipe
from app.schemas.recipe import RecipeCreate, RecipeUpdate

class CRUDRecipe(CRUDBase[Recipe, RecipeCreate, RecipeUpdate]):
    def get_by_category(self, db: Session, *, category: str, skip: int = 0, limit: int = 100) -> List[Recipe]:
        return db.query(self.model).filter(self.model.category == category).offset(skip).limit(limit).all()

    def search(self, db: Session, *, query: str, skip: int = 0, limit: int = 100) -> List[Recipe]:
        return db.query(self.model).filter(self.model.title.ilike(f"%{query}%")).offset(skip).limit(limit).all()

recipe = CRUDRecipe(Recipe)
