from typing import List, Optional
from sqlalchemy.orm import Session
from app.crud.base import CRUDBase
from app.models.order import Order, OrderItem, Cart, CartItem, OrderStatus
from app.models.recipe import Recipe
from app.schemas.order import OrderCreate, OrderItemCreate, CartItemCreate, CartItemUpdate

class CRUDCart(CRUDBase[Cart, CartItemCreate, CartItemUpdate]):
    def get_by_user(self, db: Session, *, user_id: str) -> Cart:
        cart = db.query(Cart).filter(Cart.user_id == user_id).first()
        if not cart:
            cart = Cart(user_id=user_id)
            db.add(cart)
            db.commit()
            db.refresh(cart)
        return cart

    def add_to_cart(self, db: Session, *, user_id: str, recipe_id: str, quantity: int) -> Cart:
        cart = self.get_by_user(db, user_id=user_id)
        
        # Check if item exists
        cart_item = db.query(CartItem).filter(CartItem.cart_id == cart.id, CartItem.recipe_id == recipe_id).first()
        if cart_item:
            cart_item.quantity += quantity
            if cart_item.quantity <= 0:
                db.delete(cart_item)
        elif quantity > 0:
            cart_item = CartItem(cart_id=cart.id, recipe_id=recipe_id, quantity=quantity)
            db.add(cart_item)
        
        db.commit()
        db.refresh(cart)
        return cart

    def remove_from_cart(self, db: Session, *, user_id: str, recipe_id: str) -> Cart:
        cart = self.get_by_user(db, user_id=user_id)
        cart_item = db.query(CartItem).filter(CartItem.cart_id == cart.id, CartItem.recipe_id == recipe_id).first()
        if cart_item:
            db.delete(cart_item)
            db.commit()
            db.refresh(cart)
        return cart

    def clear_cart(self, db: Session, *, user_id: str) -> Cart:
        cart = self.get_by_user(db, user_id=user_id)
        db.query(CartItem).filter(CartItem.cart_id == cart.id).delete()
        db.commit()
        db.refresh(cart)
        return cart

class CRUDOrder(CRUDBase[Order, OrderCreate, OrderCreate]):
    def create_from_cart(self, db: Session, *, user_id: str, obj_in: OrderCreate) -> Order:
        cart = crud_cart.get_by_user(db, user_id=user_id)
        if not cart.items:
            raise ValueError("Cart is empty")

        total_amount = 0.0
        order_items = []

        for cart_item in cart.items:
            recipe = db.query(Recipe).get(cart_item.recipe_id)
            if not recipe:
                continue # Should handle clearer
            
            price = recipe.price
            item_total = price * cart_item.quantity
            total_amount += item_total
            
            order_items.append(OrderItem(
                recipe_id=recipe.id,
                recipe_title=recipe.title,
                price_per_unit=price,
                quantity=cart_item.quantity
            ))

        order = Order(
            user_id=user_id,
            total_amount=total_amount,
            status=OrderStatus.PENDING.value,
            address_line=obj_in.address_line,
            latitude=obj_in.latitude,
            longitude=obj_in.longitude,
            items=order_items
        )
        
        db.add(order)
        db.commit() # Save order to get ID
        
        # Clear cart after successful order
        crud_cart.clear_cart(db, user_id=user_id)
        
        return order
        
    def get_by_user(self, db: Session, *, user_id: str, skip: int = 0, limit: int = 100) -> List[Order]:
        return db.query(Order).filter(Order.user_id == user_id).order_by(Order.created_at.desc()).offset(skip).limit(limit).all()

crud_cart = CRUDCart(Cart)
crud_order = CRUDOrder(Order)
