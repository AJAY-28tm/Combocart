from typing import List, Optional
from sqlalchemy.orm import Session
from app.crud.base import CRUDBase
from app.models.retail import RetailItem
from app.schemas.retail_subscription import RetailItemCreate, RetailItemUpdate

class CRUDRetail(CRUDBase[RetailItem, RetailItemCreate, RetailItemUpdate]):
    def get_by_category(self, db: Session, *, category: str, skip: int = 0, limit: int = 100) -> List[RetailItem]:
        return db.query(self.model).filter(self.model.category == category).offset(skip).limit(limit).all()

retail = CRUDRetail(RetailItem)
