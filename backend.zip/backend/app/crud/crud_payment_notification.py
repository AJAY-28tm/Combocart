from typing import List, Optional
from sqlalchemy.orm import Session
from app.crud.base import CRUDBase
from app.models.notification import Notification, Payment
from app.schemas.notification import NotificationCreate, PaymentRequest
from app.models.order import Order, OrderStatus
import uuid

class CRUDNotification(CRUDBase[Notification, NotificationCreate, NotificationCreate]):
    def get_by_user(self, db: Session, *, user_id: str, skip: int = 0, limit: int = 100) -> List[Notification]:
        return db.query(self.model).filter(self.model.user_id == user_id).order_by(self.model.created_at.desc()).offset(skip).limit(limit).all()

    def create_notification(self, db: Session, *, user_id: str, title: str, message: str) -> Notification:
        db_obj = Notification(user_id=user_id, title=title, message=message)
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

class CRUDPayment:
    def process_payment(self, db: Session, *, payment_in: PaymentRequest) -> Payment:
        order = db.query(Order).get(payment_in.order_id)
        if not order:
             raise ValueError("Order not found")
        if order.status != OrderStatus.PENDING.value:
             # Ideally check if already paid, but for simplicity...
             pass

        # Mock Success
        transaction_id = f"TXN_{uuid.uuid4().hex[:8].upper()}"
        
        payment = Payment(
            order_id=payment_in.order_id,
            transaction_id=transaction_id,
            provider=payment_in.provider,
            amount=payment_in.amount,
            status="SUCCESS"
        )
        db.add(payment)
        
        # Update Order Status
        order.status = OrderStatus.CONFIRMED.value
        db.add(order)
        
        # Create Notification
        crud_notification.create_notification(
            db, 
            user_id=order.user_id, 
            title="Payment Successful", 
            message=f"Your order #{order.id[:8]} has been confirmed!"
        )
        
        db.commit()
        db.refresh(payment)
        return payment

crud_notification = CRUDNotification(Notification)
crud_payment = CRUDPayment()
