from typing import List, Optional
from sqlalchemy.orm import Session
from app.crud.base import CRUDBase
from app.models.subscription import SubscriptionPlan, UserSubscription
from app.schemas.retail_subscription import SubscriptionPlanCreate, UserSubscriptionCreate, SubscriptionPlanBase
from datetime import datetime, timedelta

class CRUDSubscriptionPlan(CRUDBase[SubscriptionPlan, SubscriptionPlanCreate, SubscriptionPlanBase]):
    def get_by_name(self, db: Session, *, name: str) -> Optional[SubscriptionPlan]:
        return db.query(self.model).filter(self.model.name == name).first()

class CRUDUserSubscription(CRUDBase[UserSubscription, UserSubscriptionCreate, UserSubscriptionCreate]):
    def get_active_by_user(self, db: Session, *, user_id: str) -> Optional[UserSubscription]:
        return db.query(self.model).filter(
            self.model.user_id == user_id,
            self.model.is_active == True,
            self.model.end_date > datetime.now()
        ).first()

    def subscribe(self, db: Session, *, user_id: str, plan_id: str) -> UserSubscription:
        # Check existing active subscription and cancel/expire it? 
        # For simplicity, we assume user can only have one active.
        current_sub = self.get_active_by_user(db, user_id=user_id)
        if current_sub:
            # Logic to handle upgrade/downgrade not implemented for MVP
            current_sub.is_active = False
            db.add(current_sub)
        
        plan = db.query(SubscriptionPlan).get(plan_id)
        if not plan:
            raise ValueError("Plan not found")
            
        start_date = datetime.now()
        end_date = start_date + timedelta(days=plan.duration_days)
        
        new_sub = UserSubscription(
            user_id=user_id,
            plan_id=plan_id,
            start_date=start_date,
            end_date=end_date,
            is_active=True
        )
        db.add(new_sub)
        db.commit()
        db.refresh(new_sub)
        return new_sub

plan = CRUDSubscriptionPlan(SubscriptionPlan)
user_sub = CRUDUserSubscription(UserSubscription)
