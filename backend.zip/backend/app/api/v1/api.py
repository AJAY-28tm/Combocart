from fastapi import APIRouter

from app.api.v1.endpoints import login, users, recipes, orders, retail, subscription, payment_notification

api_router = APIRouter()
api_router.include_router(login.router, tags=["login"])
api_router.include_router(users.router, prefix="/users", tags=["users"])
api_router.include_router(recipes.router, prefix="/recipes", tags=["recipes"])
api_router.include_router(orders.router, prefix="/orders", tags=["orders"])
api_router.include_router(retail.router, prefix="/retail", tags=["retail"])
api_router.include_router(subscription.router, prefix="/subscription", tags=["subscription"])
api_router.include_router(payment_notification.router, tags=["payment_notification"]) 
