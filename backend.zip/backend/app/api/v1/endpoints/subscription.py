from typing import Any, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.orm import Session

from app import crud, models, schemas
from app.api import deps

router = APIRouter()

@router.get("/plans", response_model=List[schemas.SubscriptionPlan])
def read_plans(
    db: Session = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 100,
) -> Any:
    """
    Retrieve subscription plans.
    """
    return crud.plan.get_multi(db, skip=skip, limit=limit)

@router.post("/plans", response_model=schemas.SubscriptionPlan)
def create_plan(
    *,
    db: Session = Depends(deps.get_db),
    plan_in: schemas.SubscriptionPlanCreate,
    current_user: models.User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Create new subscription plan (Admin only).
    """
    if not current_user.is_superuser:
        raise HTTPException(status_code=400, detail="Not enough permissions")
    return crud.plan.create(db, obj_in=plan_in)

@router.post("/subscribe", response_model=schemas.UserSubscription)
def subscribe(
    *,
    db: Session = Depends(deps.get_db),
    plan_id: str = Body(..., embed=True),
    current_user: models.User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Subscribe to a plan.
    """
    try:
        return crud.user_sub.subscribe(db, user_id=current_user.id, plan_id=plan_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

@router.get("/me", response_model=Optional[schemas.UserSubscription])
def read_my_subscription(
    db: Session = Depends(deps.get_db),
    current_user: models.User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Get current user's active subscription.
    """
    return crud.user_sub.get_active_by_user(db, user_id=current_user.id)
