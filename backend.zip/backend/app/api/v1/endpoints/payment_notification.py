from typing import Any, List

from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.orm import Session

from app import crud, models, schemas
from app.api import deps

router = APIRouter()

# --- Payment Endpoints ---
@router.post("/payments/process", response_model=schemas.PaymentResponse)
def process_payment(
    *,
    db: Session = Depends(deps.get_db),
    payment_in: schemas.PaymentRequest,
    current_user: models.User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Process a mock payment.
    """
    try:
        # Security check: Ensure order belongs to user
        order = crud.order.get(db, id=payment_in.order_id)
        if not order:
             raise HTTPException(status_code=404, detail="Order not found")
        if order.user_id != current_user.id:
             raise HTTPException(status_code=400, detail="Not your order")

        payment = crud.payment.process_payment(db, payment_in=payment_in)
        return schemas.PaymentResponse(
            id=payment.id,
            transaction_id=payment.transaction_id,
            status=payment.status,
            message="Payment processed successfully"
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

# --- Notification Endpoints ---
@router.get("/notifications", response_model=List[schemas.Notification])
def read_notifications(
    db: Session = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 100,
    current_user: models.User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Get current user's notifications.
    """
    return crud.notification.get_by_user(db, user_id=current_user.id, skip=skip, limit=limit)
