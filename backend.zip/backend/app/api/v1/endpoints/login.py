from datetime import timedelta
from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from app import crud, models, schemas
from app.api import deps
from app.core import security
from app.core.config import settings

router = APIRouter()

@router.post("/login/access-token", response_model=schemas.Token)
def login_access_token(
    db: Session = Depends(deps.get_db), form_data: OAuth2PasswordRequestForm = Depends()
) -> Any:
    """
    OAuth2 compatible token login, get an access token for future requests
    """
    user = crud.user.authenticate(
        db, login_id=form_data.username, password=form_data.password
    )
    if not user:
        raise HTTPException(status_code=400, detail="Incorrect login ID or password")
    elif not crud.user.is_active(user):
        raise HTTPException(status_code=400, detail="Inactive user")
    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    return {
        "access_token": security.create_access_token(
            user.id, expires_delta=access_token_expires
        ),
        "token_type": "bearer",
    }

@router.post("/login/otp/generate", response_model=schemas.Msg)
def generate_otp(
    phone_number: str = Body(..., embed=True),
) -> Any:
    """
    Generate and send OTP to phone number.
    In development, the OTP is printed to the terminal console.
    """
    # Mock Selection logic
    otp = "1234"
    
    # Logic to send real SMS if credentials exist
    if settings.TWILIO_ACCOUNT_SID and settings.TWILIO_AUTH_TOKEN:
         try:
              # This would require 'twilio' package installed
              from twilio.rest import Client
              client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
              client.messages.create(
                  body=f"Your ComboCart OTP is: {otp}",
                  from_=settings.TWILIO_PHONE_NUMBER,
                  to=phone_number
              )
              return {"msg": "OTP sent to your phone"}
         except Exception as e:
              print(f"Failed to send SMS: {e}")
              return {"msg": "Failed to send real SMS, check logs. OTP is 1234"}

    # Fallback to Mock
    print("\n" + "="*40)
    print(f"SMS SENT TO: {phone_number}")
    print(f"CONTENT: Your ComboCart OTP is: {otp}")
    print("="*40 + "\n")
    
    return {"msg": "OTP sent successfully (Check backend console for dev)"}

@router.post("/login/otp/verify", response_model=schemas.Token)
def verify_otp(
    db: Session = Depends(deps.get_db),
    phone_number: str = Body(...),
    otp: str = Body(...)
) -> Any:
    """
    Verify OTP and return access token.
    """
    if otp != "1234":
         raise HTTPException(status_code=400, detail="Invalid OTP")
    
    # Check if user exists with phone, else register
    user = crud.user.get_by_phone(db, phone_number=phone_number)
    if not user:
        # Auto-register
        user_in = schemas.UserCreate(
            email=f"{phone_number}@combocart.com", # Placeholder email
            password=security.get_password_hash("temp_password"), # Random password
            full_name="User",
            phone=phone_number
        )
        user = crud.user.create(db, obj_in=user_in)
    
    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    return {
        "access_token": security.create_access_token(
            user.id, expires_delta=access_token_expires
        ),
        "token_type": "bearer",
    }
