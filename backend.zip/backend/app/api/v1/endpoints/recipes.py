from typing import Any, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app import crud, models, schemas
from app.api import deps

router = APIRouter()

@router.get("/", response_model=List[schemas.Recipe])
def read_recipes(
    db: Session = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 100,
    category: Optional[str] = None,
    search: Optional[str] = None,
) -> Any:
    """
    Retrieve recipes.
    """
    if category:
        recipes = crud.recipe.get_by_category(db, category=category, skip=skip, limit=limit)
    elif search:
        recipes = crud.recipe.search(db, query=search, skip=skip, limit=limit)
    else:
        recipes = crud.recipe.get_multi(db, skip=skip, limit=limit)
    return recipes

@router.post("/", response_model=schemas.Recipe)
def create_recipe(
    *,
    db: Session = Depends(deps.get_db),
    recipe_in: schemas.RecipeCreate,
    current_user: models.User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Create new recipe.
    """
    if not current_user.is_superuser:
         raise HTTPException(status_code=400, detail="Not enough permissions")
    recipe = crud.recipe.create(db, obj_in=recipe_in)
    return recipe

@router.get("/{recipe_id}", response_model=schemas.Recipe)
def read_recipe(
    *,
    db: Session = Depends(deps.get_db),
    recipe_id: str,
) -> Any:
    """
    Get recipe by ID.
    """
    recipe = crud.recipe.get(db, id=recipe_id)
    if not recipe:
        raise HTTPException(status_code=404, detail="Recipe not found")
    return recipe
