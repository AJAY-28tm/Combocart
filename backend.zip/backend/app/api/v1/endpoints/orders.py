from typing import Any, List

from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.orm import Session

from app import crud, models, schemas
from app.api import deps

router = APIRouter()

# --- Cart Endpoints ---

@router.get("/cart", response_model=schemas.Cart)
def get_cart(
    db: Session = Depends(deps.get_db),
    current_user: models.User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Get current user's cart.
    """
    cart = crud.cart.get_by_user(db, user_id=current_user.id)
    # Calulate total price dynamically for display
    total = sum([(item.recipe.price * item.quantity) for item in cart.items if item.recipe])
    # Create Pydantic model manually to inject total_price
    cart_dto = schemas.Cart.model_validate(cart)
    cart_dto.total_price = total
    return cart_dto

@router.post("/cart", response_model=schemas.Cart)
def add_to_cart(
    *,
    db: Session = Depends(deps.get_db),
    item_in: schemas.CartItemCreate,
    current_user: models.User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Add item to cart.
    """
    cart = crud.cart.add_to_cart(db, user_id=current_user.id, recipe_id=item_in.recipe_id, quantity=item_in.quantity)
    # Recalculate total for response
    total = sum([(item.recipe.price * item.quantity) for item in cart.items if item.recipe])
    cart_dto = schemas.Cart.model_validate(cart)
    cart_dto.total_price = total
    return cart_dto

@router.delete("/cart/{recipe_id}", response_model=schemas.Cart)
def remove_from_cart(
    *,
    db: Session = Depends(deps.get_db),
    recipe_id: str,
    current_user: models.User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Remove item from cart.
    """
    cart = crud.cart.remove_from_cart(db, user_id=current_user.id, recipe_id=recipe_id)
    total = sum([(item.recipe.price * item.quantity) for item in cart.items if item.recipe])
    cart_dto = schemas.Cart.model_validate(cart)
    cart_dto.total_price = total
    return cart_dto

# --- Order Endpoints ---

@router.post("/", response_model=schemas.Order)
def place_order(
    *,
    db: Session = Depends(deps.get_db),
    order_in: schemas.OrderCreate,
    current_user: models.User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Place an order from the current cart.
    """
    try:
        order = crud.order.create_from_cart(db, user_id=current_user.id, obj_in=order_in)
        return order
    except ValueError as e:
         raise HTTPException(status_code=400, detail=str(e))

@router.get("/", response_model=List[schemas.Order])
def read_orders(
    db: Session = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 100,
    current_user: models.User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Retrieve own orders.
    """
    orders = crud.order.get_by_user(db, user_id=current_user.id, skip=skip, limit=limit)
    return orders
