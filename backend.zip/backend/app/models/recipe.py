from sqlalchemy import Boolean, Column, Integer, String, Float, Text
from app.db.session import Base
import uuid

def generate_uuid():
    return str(uuid.uuid4())

class Recipe(Base):
    __tablename__ = "recipes"

    id = Column(String, primary_key=True, default=generate_uuid)
    title = Column(String, index=True, nullable=False)
    description = Column(Text, nullable=True)
    image_url = Column(String, nullable=True)
    
    cooking_time_minutes = Column(Integer, nullable=False)
    servings = Column(Integer, default=2)
    difficulty = Column(String, default="Medium") # Easy, Medium, Hard
    
    calories = Column(Integer, nullable=True)
    protein = Column(String, nullable=True) # e.g. "20g"
    carbs = Column(String, nullable=True)
    fats = Column(String, nullable=True)
    
    price = Column(Float, nullable=False)
    currency = Column(String, default="INR")
    
    category = Column(String, index=True) # Breakfast, Lunch, Dinner, Dessert
    cuisine = Column(String, index=True) # Italian, Indian, etc.
    is_vegetarian = Column(Boolean, default=False)
    
    rating = Column(Float, default=0.0)
    num_reviews = Column(Integer, default=0)
    
    # Storing lists as plain text (JSON string or delimiter separated) for MVP simplicity in SQLite
    ingredients_list = Column(Text, nullable=True) # JSON list of strings
    instructions_markdown = Column(Text, nullable=True) 
