from sqlalchemy import Column, Integer, String, Float, Text, Boolean
from app.db.session import Base
import uuid

def generate_uuid():
    return str(uuid.uuid4())

class RetailItem(Base):
    __tablename__ = "retail_items"

    id = Column(String, primary_key=True, default=generate_uuid)
    name = Column(String, index=True, nullable=False)
    description = Column(Text, nullable=True)
    price = Column(Float, nullable=False)
    image_url = Column(String, nullable=True)
    category = Column(String, index=True) # e.g., "Dairy", "Vegetables"
    stock_quantity = Column(Integer, default=0)
    is_available = Column(Boolean, default=True)
