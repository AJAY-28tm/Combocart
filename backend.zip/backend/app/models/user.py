from sqlalchemy import Boolean, Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.session import Base
import uuid

def generate_uuid():
    return str(uuid.uuid4())

class User(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, default=generate_uuid)
    phone = Column(String, unique=True, index=True, nullable=False)
    email = Column(String, unique=True, index=True, nullable=True)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String, index=True, nullable=True)
    avatar_url = Column(String, nullable=True)
    is_active = Column(Boolean, default=True)
    is_superuser = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    preferences = relationship("UserPreferences", back_populates="user", uselist=False)
    orders = relationship("Order", back_populates="user")
    # Cart is backref'd from Cart model, so no need to explicit here unless we want to, but backref works.

class UserPreferences(Base):
    __tablename__ = "user_preferences"

    id = Column(String, primary_key=True, default=generate_uuid)
    user_id = Column(String, ForeignKey("users.id"), unique=True)
    spice_level = Column(Integer, default=50) # 0-100
    sweet_tooth = Column(Integer, default=50) # 0-100
    health_focus = Column(Integer, default=50) # 0-100
    dietary_type = Column(String, default="Non-Vegetarian") # Vegetarian, Vegan, etc.
    # Storing allergies as comma-separated string for simplicity in SQLite 
    # (Postgres has ARRAY, but to be safe for both in this MVP)
    allergies = Column(String, default="") 

    user = relationship("User", back_populates="preferences")
