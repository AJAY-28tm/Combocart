from pydantic import BaseModel, ConfigDict
from typing import Optional, List

class RecipeBase(BaseModel):
    title: str
    description: Optional[str] = None
    image_url: Optional[str] = None
    cooking_time_minutes: int
    servings: int = 2
    difficulty: str = "Medium"
    calories: Optional[int] = None
    protein: Optional[str] = None
    carbs: Optional[str] = None
    fats: Optional[str] = None
    price: float
    currency: str = "INR"
    category: Optional[str] = None
    cuisine: Optional[str] = None
    is_vegetarian: bool = False
    ingredients_list: Optional[str] = None # JSON string
    instructions_markdown: Optional[str] = None

class RecipeCreate(RecipeBase):
    pass

class RecipeUpdate(RecipeBase):
    title: Optional[str] = None
    cooking_time_minutes: Optional[int] = None
    price: Optional[float] = None
    # All fields optional for update... simplifying for brevity but usually we'd repeat all Optional fields

class RecipeInDBBase(RecipeBase):
    id: str
    rating: float = 0.0
    num_reviews: int = 0

    model_config = ConfigDict(from_attributes=True)

class Recipe(RecipeInDBBase):
    pass
