from pydantic import BaseModel, ConfigDict
from typing import Optional, List
from datetime import datetime

# --- Retail Schemas ---
class RetailItemBase(BaseModel):
    name: str
    description: Optional[str] = None
    price: float
    image_url: Optional[str] = None
    category: Optional[str] = None
    stock_quantity: int = 0
    is_available: bool = True

class RetailItemCreate(RetailItemBase):
    pass

class RetailItemUpdate(RetailItemBase):
    name: Optional[str] = None
    price: Optional[float] = None

class RetailItem(RetailItemBase):
    id: str
    model_config = ConfigDict(from_attributes=True)


# --- Subscription Schemas ---
class SubscriptionPlanBase(BaseModel):
    name: str
    description: Optional[str] = None
    price: float
    duration_days: int
    features: Optional[str] = None

class SubscriptionPlanCreate(SubscriptionPlanBase):
    pass

class SubscriptionPlan(SubscriptionPlanBase):
    id: str
    model_config = ConfigDict(from_attributes=True)

class UserSubscriptionBase(BaseModel):
    plan_id: str

class UserSubscriptionCreate(UserSubscriptionBase):
    pass

class UserSubscription(BaseModel):
    id: str
    user_id: str
    plan: SubscriptionPlan
    start_date: datetime
    end_date: datetime
    is_active: bool

    model_config = ConfigDict(from_attributes=True)
