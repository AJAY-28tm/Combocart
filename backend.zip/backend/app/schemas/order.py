from pydantic import BaseModel, ConfigDict
from typing import List, Optional, Any
from datetime import datetime
from app.schemas.recipe import Recipe

# --- Cart Schemas ---
class CartItemBase(BaseModel):
    recipe_id: str
    quantity: int = 1

class CartItemCreate(CartItemBase):
    pass

class CartItemUpdate(BaseModel):
    quantity: int

class CartItem(CartItemBase):
    id: str
    cart_id: str
    recipe: Optional[Recipe] = None # Include full recipe details in cart view

    model_config = ConfigDict(from_attributes=True)

class Cart(BaseModel):
    id: str
    user_id: str
    items: List[CartItem] = []
    total_price: float = 0.0 # Computed field, not in DB

    model_config = ConfigDict(from_attributes=True)


# --- Order Schemas ---
class OrderItemBase(BaseModel):
    recipe_id: str
    quantity: int = 1

class OrderItemCreate(OrderItemBase):
    pass

class OrderItem(OrderItemBase):
    id: str
    recipe_title: str
    price_per_unit: float
    recipe: Optional[Recipe] = None  # Include full recipe details

    model_config = ConfigDict(from_attributes=True)

class OrderCreate(BaseModel):
    address_line: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    # Items are taken from Cart

class Order(BaseModel):
    id: str
    user_id: str
    total_amount: float
    status: str
    created_at: datetime
    items: List[OrderItem] = []
    address_line: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)
