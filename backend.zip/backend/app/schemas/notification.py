from pydantic import BaseModel, ConfigDict
from typing import Optional, List
from datetime import datetime

# --- Notification Schemas ---
class NotificationBase(BaseModel):
    title: str
    message: str

class NotificationCreate(NotificationBase):
    user_id: str

class Notification(NotificationBase):
    id: str
    is_read: bool
    created_at: datetime
    
    model_config = ConfigDict(from_attributes=True)

# --- Payment Schemas ---
class PaymentRequest(BaseModel):
    order_id: str
    amount: float # Should ideally correspond to order amount
    provider: str = "MockPay"

class PaymentResponse(BaseModel):
    id: str
    transaction_id: str
    status: str
    message: str
