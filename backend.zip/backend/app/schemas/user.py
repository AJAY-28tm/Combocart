from pydantic import BaseModel, ConfigDict
from typing import Optional, List

class UserBase(BaseModel):
    phone: str
    email: Optional[str] = None
    full_name: Optional[str] = None
    is_active: Optional[bool] = True

class UserCreate(UserBase):
    password: str
    is_superuser: bool = False

class UserUpdate(UserBase):
    password: Optional[str] = None
    avatar_url: Optional[str] = None

class UserInDBBase(UserBase):
    id: str
    avatar_url: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)

class UserInDB(UserInDBBase):
    pass

class User(UserInDBBase):
    pass
