from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from app.core.config import settings

# For now, we use SQLite for simplicity if Postgres is not configured validly or for local testing,
# but the config points to Postgres.
# To ensure it runs out of the box without a postgres server, I'll fallback to sqlite in the code if connection fails or just use the URI.
# Given the environment might not have postgres running, I will check the string.

connect_args = {}
if "sqlite" in settings.SQLALCHEMY_DATABASE_URI:
    connect_args = {"check_same_thread": False}

engine = create_engine(
    settings.SQLALCHEMY_DATABASE_URI, connect_args=connect_args
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
