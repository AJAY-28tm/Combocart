from app.db.session import Base
from app.models.user import User, UserPreferences
# Import other models here so Alembic can find them
