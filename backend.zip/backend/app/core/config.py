from pydantic_settings import BaseSettings
from typing import Optional, Any, Dict
from pydantic import field_validator, ValidationInfo

class Settings(BaseSettings):
    PROJECT_NAME: str = "ComboCart"
    API_V1_STR: str = "/api/v1"
    
    # CORS
    BACKEND_CORS_ORIGINS: list[str] = ["http://localhost:8000", "http://localhost:3000"]

    # DATABASE
    # SQLALCHEMY_DATABASE_URI: str = "sqlite:///./sql_app.db" # Default to SQLite for dev
    POSTGRES_SERVER: str = "localhost"
    POSTGRES_USER: str = "postgres"
    POSTGRES_PASSWORD: str = "password"
    POSTGRES_DB: str = "app" # Changed from "combocart"
    
    SQLALCHEMY_DATABASE_URI: str = "sqlite:///./sql_app.db" # Changed to SQLite

    @field_validator("SQLALCHEMY_DATABASE_URI", mode="before")
    def assemble_db_connection(cls, v: Optional[str], info: ValidationInfo) -> Any:
        if isinstance(v, str):
            return v
        return "sqlite:///./sql_app.db"
        # The following lines are commented out as per the instruction's snippet
        # return PostgresDsn.build(
        #     scheme="postgresql",
        #     user=values.get("POSTGRES_USER"),
        #     password=values.get("POSTGRES_PASSWORD"),
        #     host=values.get("POSTGRES_SERVER"),
        #     path=f"/{values.get('POSTGRES_DB') or ''}",
        # )

    # SECURITY
    SECRET_KEY: str = "YOUR_SECRET_KEY_HERE_CHANGE_IN_PRODUCTION"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7 # 7 days
    ALGORITHM: str = "HS256"
    # SMS SERVICE (Optional)
    TWILIO_ACCOUNT_SID: Optional[str] = None
    TWILIO_AUTH_TOKEN: Optional[str] = None
    TWILIO_PHONE_NUMBER: Optional[str] = None

    class Config:
        case_sensitive = True
        env_file = ".env"

settings = Settings()
