"""
Script to update recipe image_url fields in the database.
Maps each recipe to its corresponding drawable image.
"""
from app.db.session import SessionLocal
from app import models

def update_recipe_images():
    db = SessionLocal()
    
    # Mapping: Recipe Title -> Drawable name (without extension)
    image_mapping = {
        "Spicy Chicken Curry": "spicy_chicken_curry_img1",
        "Butter Chicken Combo": "butter_chicken_combo_img2",
        "Paneer Tikka Masala": "paneer_tikka_masala_img3",
        "Pasta Carbonara Kit": "pasta_carbonara_kit_img4",
        "Biryani Combo": "biriyani_combo_img5",
        "Pad Thai Kit": "pad_thai_kit_img6",
        "Margherita Pizza Kit": "margherita_pizza_kit_img7",
    }
    
    for title, drawable_name in image_mapping.items():
        recipe = db.query(models.Recipe).filter(models.Recipe.title == title).first()
        if recipe:
            image_url = f"android.resource://com.combocart/drawable/{drawable_name}"
            recipe.image_url = image_url
            print(f"Updated: {title} -> {image_url}")
        else:
            print(f"Recipe not found: {title}")
    
    db.commit()
    db.close()
    print("\nAll recipe images updated successfully!")

if __name__ == "__main__":
    print("Updating recipe images...")
    update_recipe_images()
