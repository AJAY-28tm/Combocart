import urllib.request
import json
import urllib.error

BASE_URL = "http://127.0.0.1:8000/api/v1"

def test_users():
    # 1. Login to get token
    print("1. Logging in...")
    login_url = f"{BASE_URL}/login/otp/verify"
    login_data = {"phone_number": "1234567890", "otp": "1234"}
    headers = {"Content-Type": "application/json"}
    
    try:
        req = urllib.request.Request(login_url, json.dumps(login_data).encode('utf-8'), headers)
        with urllib.request.urlopen(req) as res:
            response = json.loads(res.read().decode('utf-8'))
            token = response.get("access_token")
            print(f"   Login Success! Token: {token[:10]}...")
    except Exception as e:
        print(f"   Login Failed: {e}")
        return

    # 2. Get Current User
    print("\n2. Getting Current User...")
    me_url = f"{BASE_URL}/users/me"
    auth_headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    
    try:
        req = urllib.request.Request(me_url, headers=auth_headers)
        with urllib.request.urlopen(req) as res:
            user = json.loads(res.read().decode('utf-8'))
            print(f"   Current User: {user}")
    except Exception as e:
        print(f"   Get User Failed: {e}")

    # 3. Update User
    print("\n3. Updating User Profile...")
    update_data = {"full_name": "Updated Name", "email": "updated@example.com"}
    try:
        req = urllib.request.Request(me_url, json.dumps(update_data).encode('utf-8'), headers=auth_headers, method="PUT")
        with urllib.request.urlopen(req) as res:
            updated_user = json.loads(res.read().decode('utf-8'))
            print(f"   Updated User: {updated_user}")
            if updated_user.get("full_name") == "Updated Name":
                print("   Update Verified!")
            else:
                print("   Update verification failed.")
    except Exception as e:
        print(f"   Update User Failed: {e}")

if __name__ == "__main__":
    test_users()
