import urllib.request
import json
import time

BASE_URL = "http://127.0.0.1:8000/api/v1"

def test_retail_subscription():
    print("Testing Retail & Subscription Flow...")
    
    # 1. Login
    print("1. Logging in...")
    login_url = f"{BASE_URL}/login/otp/verify"
    login_data = {"phone_number": "1234567890", "otp": "1234"}
    headers = {"Content-Type": "application/json"}
    
    try:
        req = urllib.request.Request(login_url, json.dumps(login_data).encode('utf-8'), headers)
        with urllib.request.urlopen(req) as res:
            response = json.loads(res.read().decode('utf-8'))
            token = response.get("access_token")
    except Exception as e:
        print(f"   Login Failed: {e}")
        return

    auth_headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    # 2. Create Retail Item
    print("\n2. Creating Retail Item...")
    item_data = {
        "name": "Fresh Milk",
        "price": 60.0,
        "category": "Dairy",
        "stock_quantity": 100
    }
    try:
        req = urllib.request.Request(f"{BASE_URL}/retail/", json.dumps(item_data).encode('utf-8'), headers=auth_headers)
        with urllib.request.urlopen(req) as res:
            item = json.loads(res.read().decode('utf-8'))
            print(f"   Created Item: {item['name']} (ID: {item['id']})")
    except Exception as e:
        print(f"   Create Retail Item Failed: {e}")

    # 3. Create Subscription Plan
    print("\n3. Creating Subscription Plan...")
    plan_data = {
        "name": "Gold Member",
        "price": 999.0,
        "duration_days": 30,
        "description": "Free delivery + 10% off"
    }
    try:
        req = urllib.request.Request(f"{BASE_URL}/subscription/plans", json.dumps(plan_data).encode('utf-8'), headers=auth_headers)
        with urllib.request.urlopen(req) as res:
            plan = json.loads(res.read().decode('utf-8'))
            plan_id = plan['id']
            print(f"   Created Plan: {plan['name']} (ID: {plan_id})")
    except Exception as e:
        print(f"   Create Plan Failed: {e}")
        return

    # 4. Subscribe
    print("\n4. Subscribing to Plan...")
    sub_data = {"plan_id": plan_id}
    try:
        req = urllib.request.Request(f"{BASE_URL}/subscription/subscribe", json.dumps(sub_data).encode('utf-8'), headers=auth_headers)
        with urllib.request.urlopen(req) as res:
            sub = json.loads(res.read().decode('utf-8'))
            print(f"   Subscribed! Valid until: {sub['end_date']}")
    except Exception as e:
        print(f"   Subscribe Failed: {e}")
        try: print(e.read().decode()) 
        except: pass

    # 5. Get My Subscription
    print("\n5. Checking My Subscription...")
    try:
        req = urllib.request.Request(f"{BASE_URL}/subscription/me", headers=auth_headers)
        with urllib.request.urlopen(req) as res:
            sub = json.loads(res.read().decode('utf-8'))
            if sub:
                print(f"   Active Subscription: Plan ID {sub['plan']['name']} (Active: {sub['is_active']})")
            else:
                print("   No active subscription.")
    except Exception as e:
        print(f"   Get Subscription Failed: {e}")

if __name__ == "__main__":
    time.sleep(2)
    test_retail_subscription()
